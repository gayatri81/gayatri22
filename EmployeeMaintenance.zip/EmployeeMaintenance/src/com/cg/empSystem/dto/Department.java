package com.cg.empSystem.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity(name="department")
@Table(name="DEPARTMENT")

@NamedQueries({
	@NamedQuery(name="getdeptId", query="select d from department d where deptName=:dName"),
	@NamedQuery(name="getDeptname",query="select d from department d where deptId is :deptId")
})
public class Department {

	
	private int deptId;
	private String deptName;
	private List<Employee> empList;
	
	@Id
	@Column(name="DEPT_ID")
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	
	@Column(name="DEPT_NAME")
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", deptName=" + deptName + "]";
	}
	
	

	
	
}
