package com.cg.empSystem.dto;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.NotEmpty;



@Entity(name="employee")
@Table(name="EMPLOYEE")
@NamedQueries({ @NamedQuery(name = "qryAllEmps" , query = "select e from employee e"),
				@NamedQuery(name = "qrySearchEmployeeByFirstName" , query = "select e from employee e where empFname like CONCAT(:firstName, '%' )"),
				@NamedQuery(name = "qrySearchEmployeeByLastName" , query = "select e from employee e where empLname like CONCAT(:lastName, '%' )"),
				@NamedQuery(name = "qrySearchEmployeeByMaritalStatus" , query = "select e from employee e where empMaritalStatus is :maritalStatus"),
				@NamedQuery(name="qryGrade",query="select e from employee e where empGrade is :grade"),
				@NamedQuery(name = "empOnDeptName" , query = "select e from employee e where empDeptId is :id ")



})

public class Employee implements Serializable{



	private static final long serialVersionUID = 1L;
	
	//Data Members going to be used 
	private String empId;
	private String empFname;
	private String empLname;
	private Date empDateOfBirth;
	private Date empDateOfJoining;
	private int empDeptId;
	private String deptName;
	private String empGrade;
	private String empDesignation;
	private String empBasic;
	private String empGender;
	private String empMaritalStatus;
	private String empHomeAddress;
	private String empContactNo;
	
	//Associated data members
	private Department dept;
	private Grade grade;
	
	//private UserMaster user;
	@Id
	@Column(name="EMP_ID")
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	
	@Column(name="EMP_FIRST_NAME")
	@NotEmpty(message="*Please Enter First Name")
	@Size(min=3,max=25,message="*Please enter valid First Name")
	@Pattern(regexp="[A-Za-z]*",message="*First Name should be alphabet only")
	public String getEmpFname() {
		return empFname;
	}
	public void setEmpFname(String empFname) {
		this.empFname = empFname;
	}
	
	@Column(name="EMP_LAST_NAME")
	@NotEmpty(message="*Please Enter Last Name")
	@Size(min=3,max=25,message="*Please enter valid Last Name")
	@Pattern(regexp="[A-Za-z]*",message="*Last Name should be contain alphabet only")
	public String getEmpLname() {
		return empLname;
	}
	public void setEmpLname(String empLname) {
		this.empLname = empLname;
	}
	
	@Column(name="EMP_DATE_OF_BIRTH")
	public Date getEmpDateOfBirth() {
		return empDateOfBirth;
	}
	public void setEmpDateOfBirth(Date empDateOfBirth) {
		this.empDateOfBirth = empDateOfBirth;
	}
	
	@Column(name="EMP_DATE_OF_JOINING")
	public Date getEmpDateOfJoining() {
		return empDateOfJoining;
	}
	public void setEmpDateOfJoining(Date empDateOfJoining) {
		this.empDateOfJoining = empDateOfJoining;
	}
	
	@Column(name="EMP_DESIGNATION")
	@Size(max=50,message="*Designation name should be less than 50 Characters")
	@Pattern(regexp="[A-Za-z ]*",message="*Desination should contain alphabet only")
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	
	
	@Column(name="EMP_BASIC")
	@NotEmpty(message="*Please Enter Basic Salary")
	@Pattern(regexp="[1-9]{1}[0-9]*",message="*Salary should be in numbers only")
	public String getEmpBasic() {
		return empBasic;
	}
	public void setEmpBasic(String empBasic) {
		this.empBasic = empBasic;
	}
	
	@Column(name="EMP_GENDER")
	@NotEmpty(message="*Please Select Gender")
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	
	@Column(name="EMP_MARITAL_STATUS")
	@NotEmpty(message="*Please Select Marital Status")
	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}
	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}
	
	@Column(name="EMP_HOME_ADDRESS")
	public String getEmpHomeAddress() {
		return empHomeAddress;
	}
	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}
	
	@Column(name="EMP_CONTACT_NUM")
	public String getEmpContactNo() {
		return empContactNo;
	}
	public void setEmpContactNo(String empContactNo) {
		this.empContactNo = empContactNo;
	}
	
	@Column(name="EMP_DEPT_ID")
	public int getEmpDeptId() {
		return empDeptId;
	}
	public void setEmpDeptId(int empDeptId) {
		this.empDeptId = empDeptId;
	}
	
	@Column(name="EMP_GRADE")
	@NotEmpty(message="*Please Select Grade")
	public String getEmpGrade() {
		return empGrade;
	}
	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}
	
	
	
	@Transient
	//@NotEmpty(message="*Please Select Department")
	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFname=" + empFname
				+ ", empLname=" + empLname + ", empDateOfBirth="
				+ empDateOfBirth + ", empDateOfJoining=" + empDateOfJoining
				+ ", empDeptId=" + empDeptId + ", deptName=" + deptName
				+ ", empGrade=" + empGrade + ", empDesignation="
				+ empDesignation + ", empBasic=" + empBasic + ", empGender="
				+ empGender + ", empMaritalStatus=" + empMaritalStatus
				+ ", empHomeAddress=" + empHomeAddress + ", empContactNo="
				+ empContactNo + ", dept=" + dept + ", grade=" + grade + "]";
	}
	

	
	
	

	
	
	
	
}
