package com.cg.empSystem.dao;

import java.util.List;
import java.util.Random;
import java.security.SecureRandom;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.empSystem.dto.Department;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.dto.Grade;
import com.cg.empSystem.dto.UserMaster;
import com.cg.empSystem.exception.EmployeeException;

/**************************************************************************
File Name            :Employee Maintainance System
Class Name           :EmployeeDaoImpl.java
Date                 :13-04-2017
Description          :Implementation of interface which is having methods for employee maintainance.
***************************************************************************/
@Repository("empDao")
public class EmployeeDaoImpl implements EmployeeDao
{
    	
	@PersistenceContext
	private EntityManager manager;
	
	/*********************Declaring the variable to have the random password*******************/
	
	private static final Random RANDOM = new SecureRandom();
	public static final int PASSWORD_LENGTH = 6;
	
	
	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :addUser(Employee emp)
	Date                 :13-04-2017
	***************************************************************************/
	@Override
	public UserMaster addUser(Employee emp) throws EmployeeException {
		UserMaster usermaster = new UserMaster();
		try{
			String userId=usermaster.getUserId();
			
			String userPwd = this.generateRandomPassword();
			String userNm = this.generateUserName(emp);	
			usermaster.setUserId(userId);
			usermaster.setUserName(userNm);
			usermaster.setUserPassword(userPwd);
			usermaster.setUserType("Employee");
			manager.persist(usermaster);
			manager.flush();
			
			String empId = usermaster.getUserId();
			emp.setEmpId(empId);
			this.addEmp(emp);
		}
		catch(RollbackException rl)
		{

			throw new EmployeeException("User data is duplicated",rl);
		}
		return usermaster;
	}
	
	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :addEmp(Employee emp)
	Date                 :13-04-2017
	***************************************************************************/

	public Employee addEmp(Employee emp) throws EmployeeException 
	{
		try 
		{
			String deptName = emp.getDeptName();
			Department dept = this.getDeptId(deptName);
			dept.setDeptId(dept.getDeptId());
			emp.setEmpDeptId(dept.getDeptId());
			
			manager.persist(emp);
			manager.flush();
		} 
		catch (RollbackException rl) 
		{
			throw new EmployeeException("Employee data is duplicated",rl);
		}
		return emp;
	}

	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :getDeptname()
	Date                 :13-04-2017
	***************************************************************************/
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getDeptname() throws EmployeeException 
	{
		List<String> deptNmList;
		try 
		{
			Query qry = manager.createQuery("select d.deptName from department as d");
			deptNmList = qry.getResultList();
		} 
		catch (Exception e) 
		{
			throw new EmployeeException("Improper query fabrication",e);
		}
		return deptNmList;
	}
	
	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :getDeptname()
	Date                 :13-04-2017
	***************************************************************************/

	
	public Department getDeptId(String deptName) throws EmployeeException {
		Department dept = null;
		try {
			TypedQuery<Department> qry = manager.createNamedQuery("getdeptId",Department.class);
			qry.setParameter("dName", deptName);
			dept = qry.getSingleResult();
		} catch (Exception e) {
			throw new EmployeeException("Improper query fabrication",e);
		}
		return dept;
	}
	
	
	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :getDeptname()
	Date                 :13-04-2017
	***************************************************************************/

	public String generateRandomPassword(){
	      String letters = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ0123456789";

	      String pw = "";
	      for (int i=0; i<PASSWORD_LENGTH; i++)
	      {
	          int index = (int)(RANDOM.nextDouble()*letters.length());
	          pw += letters.substring(index, index+1);
	      }
	      return pw;
	  }
	
	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :getDeptname()
	Date                 :13-04-2017
	***************************************************************************/

	public String generateUserName(Employee emp){
		String userName = null;		
		String fName = emp.getEmpFname();
		if(fName.length()>=6){
			int a = (int) (Math.random()*100);
			userName = fName.substring(0,6)+"."+a;
		}else{
			int a = (int) (Math.random()*100);
			userName = fName.toLowerCase()+"."+a;
		}
		return userName;
	} 
	
	//Change Password
	
		@Override
		public UserMaster getUserDetails(String userId) throws EmployeeException {
			UserMaster user = new UserMaster();
			try {
				user = manager.find(UserMaster.class, userId);
			} catch (RollbackException rl) {
				throw new EmployeeException("Employee does not exist",rl);
			}
			return user;
		}
	//End of Add 

		/**************************************************************************
		File Name            :Employee Maintainance System
		Method Name          :getDeptname()
		Date                 :13-04-2017
		***************************************************************************/

	@Override
	public List<Employee> showAllEmployee() throws EmployeeException {
		Query qry= manager.createNamedQuery("qryAllEmps", Employee.class);
		List<Employee> e=qry.getResultList();
		System.out.println(e);
		return e;
	}//End of Show All
	
	
	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :getDeptname()
	Date                 :13-04-2017
	***************************************************************************/
	@Override
	public List<Employee> searchEmployeeOnFirstName(String firstName)throws EmployeeException {
		TypedQuery<Employee> qry = manager.createNamedQuery("qrySearchEmployeeByFirstName", Employee.class);
		qry.setParameter("firstName", firstName);
		return qry.getResultList();
	}

	
	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :getDeptname()
	Date                 :13-04-2017
	***************************************************************************/
	@Override
	public List<Employee> searchEmployeeOnLastName(String lastName)throws EmployeeException {
		TypedQuery<Employee> qry = manager.createNamedQuery("qrySearchEmployeeByLastName", Employee.class);
		qry.setParameter("lastName", lastName);
		return qry.getResultList();
	}

	
	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :getDeptname()
	Date                 :13-04-2017
	***************************************************************************/
	@Override
	public List<Employee> searchEmployeeOnMaritalStatus(String maritalStatus)
			throws EmployeeException {
		TypedQuery<Employee> qry = manager.createNamedQuery("qrySearchEmployeeByMaritalStatus", Employee.class);
		qry.setParameter("maritalStatus", maritalStatus);
		return qry.getResultList();
	}
	
	
	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :getDeptname()
	Date                 :13-04-2017
	***************************************************************************/
	@Override
	public List<Employee> searchEmployeeOnDeptName(String deptName) throws EmployeeException{
		try 
		{
			Department dept=this.getDeptId(deptName);
			System.out.println(dept);
	        int id=	dept.getDeptId();
			System.out.println(id);
	        Query qry= manager.createNamedQuery("empOnDeptName", Employee.class);
	         qry.setParameter("id", id);
	
	       return qry.getResultList();
			
			
			
		} catch (EmployeeException e) 
		{
			throw new EmployeeException(e.getMessage());
		}
		
	       
 
	}

	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :SearchGrade(String grade)
	Date                 :13-04-2017
	***************************************************************************/
	 	@SuppressWarnings("unchecked")
		@Override
		public List<Employee> SearchGrade(String grade) throws EmployeeException 
	 	{
				
			Query qry=manager.createNamedQuery("qryGrade",Employee.class);
			qry.setParameter("grade",grade);
			List<Employee> qry1= qry.getResultList();
		
			return qry1;
			}
		/**************************************************************************
		File Name            :Employee Maintainance System
		Method Name          :getData(String grade)
		Date                 :13-04-2017
		***************************************************************************/

	       
		  @SuppressWarnings("unchecked")
		  @Override
		  public List<Grade> getData(String grade) throws EmployeeException
		  {
			  Query qry=manager.createNamedQuery("getGrade",Grade.class);
			  qry.setParameter("grade", grade);
				
				List<Grade> qry1= qry.getResultList();
				
				return qry1;
		  }
		  
	/**************************************************************************
    File Name            :Employee Maintainance System
    Method Name          :isValid(String userName, String userPassword)
	Date                 :13-04-2017
	***************************************************************************/
	@Override
	public int isValid(String userName, String userPassword) 
	{
		try { System.out.println("in dao isVakid");
		System.out.println(userName+userPassword);
		//String qry="select u from usermaster u where userName is :name";
		TypedQuery<UserMaster> result= manager.createNamedQuery("qry", UserMaster.class);
		result.setParameter("name", userName);
		UserMaster	user = (UserMaster) result.getSingleResult();
		
		System.out.println(user);
		
			if(user.getUserType().equals("admin"))
			{
				if(user.getUserPassword().equals(userPassword))
				{
					return 1;
				}//admin verified
			}
			
			else
			{
				if(user.getUserPassword().equals(userPassword))
				{
					return 2;
				}//employee verified
			}
		
	}	catch (Exception e1) {
		return 0;
	}
		
	return 0;
	}
	
	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :updateEmp(Employee emp)
	Date                 :13-04-2017
	***************************************************************************/
	@Override
	public boolean updateEmp(Employee emp) throws EmployeeException 
	{
		
		Employee empl=manager.merge(emp);
		manager.flush();
		return false;
	}

	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :searchId(String Id)
	Date                 :13-04-2017
	***************************************************************************/

	@Override
	public Employee searchId(String Id) throws EmployeeException 
	{
		Employee emp=manager.find(Employee.class, Id);
		return emp;
	}

	/**************************************************************************
	File Name            :Employee Maintainance System
	Method Name          :getDeptName(int deptId)
	Date                 :13-04-2017
	***************************************************************************/

	@Override
	public Department getDeptName(int deptId) throws EmployeeException {
		System.out.println(deptId);
		TypedQuery<Department> qry=manager.createNamedQuery("getDeptname", Department.class);
		qry.setParameter("deptId", deptId);
		Department dept=qry.getSingleResult();
		String deptname=dept.getDeptName();
		System.out.println(dept.getDeptName());
		return dept;
	}
	//End of update data
	
	

	
}
