package com.cg.empSystem.service;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.empSystem.dao.EmployeeDao;
import com.cg.empSystem.dto.Department;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.dto.Grade;
import com.cg.empSystem.dto.UserMaster;
import com.cg.empSystem.exception.EmployeeException;

/**************************************************************************
File Name            :Employee Maintainance System
Class Name           :EmployeeServiceImpl.java
Date                 :13-04-2017
Description          :Interface implementation for service class of employee.
***************************************************************************/

@Transactional
@Service("empService")
public class EmployeeServiceImpl implements EmployeeService
{

	private EmployeeDao empDao;
	
	@Resource(name="empDao")
	public void setEmpDao(EmployeeDao empDao)
	{
		this.empDao = empDao;
	}
	
	@Override
	public UserMaster addUser(Employee emp) throws EmployeeException 
	{
		return empDao.addUser(emp);
	}

	@Override
	public List<String> getDeptname() throws EmployeeException 
	{
		return empDao.getDeptname();
	}

	
	@Override
	public List<Employee> searchEmployeeOnFirstName(String firstName)throws EmployeeException 
	{
		
		return empDao.searchEmployeeOnFirstName(firstName);
	}

	@Override
	public List<Employee> searchEmployeeOnLastName(String lastName)throws EmployeeException 
	{
		
		return empDao.searchEmployeeOnLastName(lastName);
	}


	@Override
	public List<Employee> searchEmployeeOnMaritalStatus(String maritalStatus)throws EmployeeException 
	{
		
		return empDao.searchEmployeeOnMaritalStatus(maritalStatus);
	}

	@Override
	public List<Employee> showAllEmployee() throws EmployeeException 
	{
		// TODO Auto-generated method stub
		return empDao.showAllEmployee();
	}
	
	@Override
	public int isValid(String userName, String userPassword) throws EmployeeException 
	{
		// TODO Auto-generated method stub
		return empDao.isValid(userName, userPassword);
	}

	@Override
	public List<Employee> SearchGrade(String grade) throws EmployeeException 
	{
		
		return empDao.SearchGrade(grade);
	}

	@Override
	public List<Grade> getData(String grade) throws EmployeeException 
	{
		// TODO Auto-generated method stub
		return empDao.getData(grade);
	}
	
	@Override
	public boolean updateEmp(Employee emp) throws EmployeeException 
	{
		
		return empDao.updateEmp(emp);
	}

	@Override
	public Employee searchId(String id) throws EmployeeException 
	{
		return empDao.searchId(id);
	}

	@Override
	public Department getDeptName(int deptId) throws EmployeeException 
	{
		
		return empDao.getDeptName(deptId);
	}

	@Override
	public List<Employee> searchEmployeeOnDeptName(String deptName)throws EmployeeException 
	{
		
		return empDao.searchEmployeeOnDeptName(deptName);
	}

	@Override
	public UserMaster getUserDetails(String userId) throws EmployeeException 
	{
		return empDao.getUserDetails(userId);
	}

}
