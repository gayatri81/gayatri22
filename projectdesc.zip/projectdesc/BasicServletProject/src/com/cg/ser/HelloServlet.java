package com.cg.ser;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet(name = "HelloServletName", urlPatterns = { "/HelloServletMap" },
initParams={@WebInitParam(name="compName",value="Capgemini"),   
		    @WebInitParam(name="compLoc",value="Pune")})
public class HelloServlet extends HttpServlet 
{   ServletConfig conf;
	private static final long serialVersionUID = 1L;
       
    
    public HelloServlet() 
    {
        super();
        System.out.println("HelloServlet() Initialized");
       
    }

	
	public void init(ServletConfig config) throws ServletException 
	{    conf=config;
		System.out.println("init function of HelloServlet Called");
	}

	
	public void destroy() 
	{
		System.out.println("Destroy function of HelloServlet Called");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println(""+"In Do Get******************");
		doPost(request,response);

	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String name=request.getParameter("txtName");
		String cn=conf.getInitParameter("compName");
		String cl=conf.getInitParameter("compLoc");
		//String pwd=request.getParameter("txtPwd");
		System.out.println(""+"In doPost********************");
		PrintWriter out=response.getWriter();
		out.println("<hr/>");
		out.println("Welcome to :" +cn+name+"To"+cl);
		
		out.println("<hr color='pink' size='5'/>");
	}

	
	
}
