package com.cg.ser;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "SuccessServletName", urlPatterns = { "/SuccessServletMap" })
public class SuccessServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
     ServletConfig conf; 
    public SuccessServlet()
    {
        super();   
    }

	public void init(ServletConfig config) throws ServletException
	{   conf=config;
		System.out.println("In SuccessServlet Init*********");
	}

	public void destroy() 
	{
        System.out.println("In SuccessServlet Destroy************");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		System.out.println("In doGet of SuccessServlet********");
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ServletContext ctx=conf.getServletContext();
		
		String cn=ctx.getInitParameter("countryName");
		String sn=ctx.getInitParameter("compState");
		
		RequestDispatcher rdH=ctx.getRequestDispatcher("/Header.html");
		RequestDispatcher rdF=ctx.getRequestDispatcher("/Footer.html");
		PrintWriter pw=response.getWriter();
		rdH.include(request,response);
	
		String unm=request.getParameter("txtUN");
		pw.println("<font color='blue'>Welcome...U are valid user :"+"</font>"+unm);
		pw.println("<br/>Your State and Country Name is:"+sn+" "+cn);
	
		rdF.include(request,response);
	}

}
