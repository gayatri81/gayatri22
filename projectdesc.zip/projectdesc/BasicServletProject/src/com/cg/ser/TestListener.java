package com.cg.ser;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class TestListener implements ServletContextListener
{

	@Override
	public void contextDestroyed(ServletContextEvent arg0) 
	{
			
	}

	@Override
	public void contextInitialized(ServletContextEvent sce)
	{
		System.out.println("TestListener ContextInitialized Fun Called");
		ServletContext ctx=sce.getServletContext();
		ctx.setInitParameter("compState", "Maharashtra");
		
		
	}

}
