package com.cg.ser;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.User;
import com.cg.service.IUserService;
import com.cg.service.IUserServiceImpl;


@WebServlet(name = "LoginServletName", urlPatterns = { "/LoginServletMap" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	IUserService userservice;
    public LoginServlet() 
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		System.out.println("Init of Loginservlet Called");
	}



	public void destroy() 
	{
		System.out.println("Destroy of LoginSerlet Called");

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
       doPost(request,response);
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		userservice=new IUserServiceImpl();
        System.out.println("In doPost of LoginServlet");
        String un=request.getParameter("txtUN");
        String pw=request.getParameter("txtPwd");
        
        if(userservice.isUserExist(un))
        {
        	User user=userservice.getUser(un);
        	
        	if(un.equalsIgnoreCase(user.getUsername())&& pw.equalsIgnoreCase(user.getPassword()))
        	{
        		
        	RequestDispatcher rsUserExist=request.getRequestDispatcher("/SuccessServletMap");
        	rsUserExist.forward(request, response);
        	}
        	else
        	{
        		RequestDispatcher rdfailure=request.getRequestDispatcher("/Failure.html");
        		rdfailure.forward(request, response);
        	}
        }
        else
        {
        	RequestDispatcher rsUserNotExist=request.getRequestDispatcher("/Register.html");
        	rsUserNotExist.forward(request, response);
        }
        
        
        


	}

}
