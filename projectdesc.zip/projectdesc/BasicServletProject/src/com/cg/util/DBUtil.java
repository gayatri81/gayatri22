
package com.cg.util;
import java.sql.Connection;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBUtil 
{

	public static Connection getConnection() 
	{
         InitialContext ic;
         DataSource ds;
         Connection con=null;
		 try 
		 {
			 
			 if(con==null)
		   {
			 ic=new InitialContext();
			 ds=(DataSource) ic.lookup("java:/jdbc/OracleDS");
			 con=ds.getConnection();
			 return con;
		 }
		} 
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
		
		
		
//			OracleDataSource ods=new OracleDataSource();
//			
//			
//			//set the username, password ,driver type and network protocol
//			
//			ods.setUser("Labg103trg7");
//			ods.setPassword("labg103oracle");
//			ods.setDriverType("oracle.jdbc.driver.OracleDriver");
//			ods.setNetworkProtocol("tcp");
//			ods.setURL("jdbc:oracle:thin:@10.125.6.62:1521:orcl11g");
			
			return con;
		}
		

	}


