package com.cg.service;

import com.cg.bean.User;

public interface IUserService 
{
	 public boolean isUserExist(String unm);
	  public User getUser(String unm);
}
