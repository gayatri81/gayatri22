package com.cg.service;

import com.cg.bean.User;
import com.cg.dao.IUsersDAO;
import com.cg.dao.UsersDAOImpl;

public class IUserServiceImpl implements IUserService 
{
     IUsersDAO userdao;
     
     public IUserServiceImpl() 
    {
 		userdao = new UsersDAOImpl();
 	}

	@Override
	public boolean isUserExist(String unm) 
	{
		return userdao.isUserExist(unm);
		
	}

	
	@Override
	public User getUser(String unm)
	{
		
	return userdao.getUser(unm);
	}

}
