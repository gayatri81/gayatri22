package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.bean.User;
import com.cg.util.DBUtil;

public class UsersDAOImpl implements IUsersDAO
{    
	boolean flag=false;
	Connection con;
	Statement st;
	PreparedStatement pst;

	
	ResultSet rs;
	@Override
	public boolean isUserExist(String unm) 
	{
		
		con=DBUtil.getConnection();
		
		System.out.println("In Users DAO user is "+con);
		
		String str="select count(*) from CG_Users  where User_Name=?";
		
		try 
		{
			pst=con.prepareStatement(str);
			pst.setString(1, unm);
			rs=pst.executeQuery();
			rs.next();
			int count=rs.getInt(1);
			if(count==1)
			{
				flag= true;
			}
			else
			{
				System.out.println("*********"+rs);
				flag= false;
			}
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return flag;
	}

	@Override
	public User getUser(String un) 
	{
		con=DBUtil.getConnection();
		System.out.println("getUserDetails************con is***"+con);
		String selQry="select * from CG_Users where User_Name=?";
		User usr=new User();
		try 
		{
			pst=con.prepareStatement(selQry);
			pst.setString(1, un);
			rs=pst.executeQuery();
			rs.next();
			usr.setUsername(rs.getString("user_name"));
			usr.setPassword(rs.getString("Password"));
		
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
              e.printStackTrace();
			}
		}
		return usr;
	}

}
