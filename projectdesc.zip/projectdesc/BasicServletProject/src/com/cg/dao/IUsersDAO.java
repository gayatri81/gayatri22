package com.cg.dao;

import com.cg.bean.User;

public interface IUsersDAO 
{
   public boolean isUserExist(String unm);
   public User getUser(String unm);
   
   
}
