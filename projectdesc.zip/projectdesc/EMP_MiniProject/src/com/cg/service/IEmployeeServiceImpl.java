package com.cg.service;


import com.cg.bean.Employee;
import com.cg.bean.UserBean;
import com.cg.dao.IEmployeeDAOImpl;
import com.cg.dao.IEmployeeDAO;
import com.cg.exception.EmployeeException;
import com.cg.exception.UserException;

public class IEmployeeServiceImpl implements IEmployeeService {
	
private IEmployeeDAO employeeDAO;
	
	public IEmployeeServiceImpl(){
		
		employeeDAO = new IEmployeeDAOImpl();
	}
	

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		
		return employeeDAO.addEmployee(employee);
	}

	@Override
	public Employee getEmployee(int empId) throws EmployeeException {
		
		return employeeDAO.getEmployee(empId);
	}

	@Override
	public Employee getEmployeeDetailsByFName(String Fname)
			throws EmployeeException {
		
		return employeeDAO.getEmployeeDetailsByFName(Fname);
	}

	@Override
	public Employee getEmployeeDetailsByLName(String Lname)
			throws EmployeeException {
		
		return employeeDAO.getEmployeeDetailsByLName(Lname);
	}


	@Override
	public Employee getEmployeeByDept(int deptId) throws EmployeeException {
		
		return employeeDAO.getEmployeeByDept(deptId);
	}


	@Override
	public Employee getEmployeeByGrade(String grade) throws EmployeeException 
	{
		
		return employeeDAO.getEmployeeByGrade(grade);
	}


	@Override
	public Employee getEmployeeByMaritalStatus(String MaritalStatus)
			throws EmployeeException 
	{
		
		return employeeDAO.getEmployeeByMaritalStatus(MaritalStatus);
	}


	@Override
	public UserBean getUserDetails(String name, String password)
			throws UserException 
	{
		
		return employeeDAO.getUserDetails(name, password);
	}

}
