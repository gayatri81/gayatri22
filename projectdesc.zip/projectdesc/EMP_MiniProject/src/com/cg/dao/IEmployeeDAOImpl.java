package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.bean.Employee;
import com.cg.bean.UserBean;
import com.cg.exception.EmployeeException;
import com.cg.exception.UserException;
import com.cg.util.DBUtil;


public class IEmployeeDAOImpl implements IEmployeeDAO {
	

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		
		int generatedId = -1;
		
		
		try(Connection con = DBUtil.getConnection()){
			
		
		Statement stm = con.createStatement();
		
		ResultSet res = 
				stm.executeQuery("select empIdSeq1.nextVal from dual");
		
		if(res.next() == false)
			throw new EmployeeException("Something went wrong while generating employee id");
		
		
		int id = res.getInt(1);
	
		
		/*	String fname = res.getString(2);
		String lname = res.getString(3);
		Date dob = res.getDate(4);
		Date doj = res.getDate(5);
		int depid = res.getInt(6);
		String grade = res.getString(7);
		String desg = res.getString(8);
		int basic = res.getInt(9);
		String gender = res.getString(10);
		String MarSt = res.getString(11);
		String HoAdd = res.getString(12);
		String Cnum = res.getString(13);*/
		
		PreparedStatement pstm = con.prepareStatement("insert into Employee1 values(empIdSeq1.nextVal,?,?,?,?,?,?,?,?,?,?,?,?)");
		
		/*pstm.setInt(1, id);*/
		pstm.setString(1, employee.getFname());
		pstm.setString(2, employee.getLname());
		pstm.setDate(3, employee.getDOB());
		pstm.setDate(4, employee.getDOJ());
		pstm.setInt(5, employee.getDeptId());
		pstm.setString(6, employee.getGrade());
		pstm.setString(7, employee.getDesignation());
		pstm.setInt(8, employee.getBasic());
		pstm.setString(9, employee.getGender());
		pstm.setString(10, employee.getMaritalStatus());
		pstm.setString(11, employee.getHomeAddress());
		pstm.setString(12, employee.getCNum());
		
		//pstm.execute();
		pstm.executeUpdate();
		
		generatedId = id;
		
		
		}
		catch(SQLException e){
			
		e.printStackTrace();
		
		throw new EmployeeException(e.getMessage());
		
		}
		catch(Exception e){
		
		throw new EmployeeException(e.getMessage());
		}
			
		return generatedId;
	}

	@Override
	public Employee getEmployee(int empId) throws EmployeeException {
		
		Employee employee = null;
		
		try(Connection con = DBUtil.getConnection() ){
			
			PreparedStatement pstm = con.prepareStatement("select * from Employee1 where Emp_ID=?");
			
			pstm.setInt(1, empId);
			
			ResultSet res = pstm.executeQuery();
			
			if(res.next() == false)
				throw new EmployeeException("No Employee Found with id "+ empId);
			
			employee = new Employee();
			
			
			employee.setEmpId(res.getInt("Emp_ID"));
			employee.setFname(res.getString("Emp_First_Name"));
			employee.setLname(res.getString("Emp_Last_Name"));
			employee.setDOB(res.getDate("Emp_Date_of_Birth"));
			employee.setDOJ(res.getDate("Emp_Date_of_Joining"));
			employee.setDeptId(res.getInt("Emp_Dept_ID"));
			employee.setGrade(res.getString("Emp_Grade"));
			employee.setDesignation(res.getString("Emp_Designation"));
			employee.setBasic(res.getInt("Emp_Basic"));
			employee.setGender(res.getString("Emp_Gender"));
			employee.setMaritalStatus(res.getString("Emp_Marital_Status"));
			employee.setHomeAddress(res.getString("Emp_Home_Address"));
			employee.setCNum(res.getString("Emp_Contact_Num"));
			
			
			
		}
		catch(SQLException e){
			
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
			
		}
		catch(Exception e){
			
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		return employee;
	}

	@Override
	public Employee getEmployeeDetailsByFName(String Fname)
			throws EmployeeException {
		
		Employee employee = null;
		
		try(Connection con = DBUtil.getConnection() ){
			
			PreparedStatement pstm = con.prepareStatement("select * from Employee1 where Emp_First_Name=?");
			
			pstm.setString(1, Fname);
			
			ResultSet res = pstm.executeQuery();
			
			if(res.next() == false)
				throw new EmployeeException("No Employee Found with first name "+ Fname);
			
			employee = new Employee();
			
			employee.setEmpId(res.getInt("Emp_ID"));
			employee.setFname(res.getString("Emp_First_Name"));
			employee.setLname(res.getString("Emp_Last_Name"));
			employee.setDOB(res.getDate("Emp_Date_of_Birth"));
			employee.setDOJ(res.getDate("Emp_Date_of_Joining"));
			employee.setDeptId(res.getInt("Emp_Dept_ID"));
			employee.setGrade(res.getString("Emp_Grade"));
			employee.setDesignation(res.getString("Emp_Designation"));
			employee.setBasic(res.getInt("Emp_Basic"));
			employee.setGender(res.getString("Emp_Gender"));
			employee.setMaritalStatus(res.getString("Emp_Marital_Status"));
			employee.setHomeAddress(res.getString("Emp_Home_Address"));
			employee.setCNum(res.getString("Emp_Contact_Num"));
			
			
			
		}
		catch(SQLException e){
			
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
			
		}
		catch(Exception e){
			
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		return employee;
	
		
	}

	@Override
	public Employee getEmployeeDetailsByLName(String Lname)
			throws EmployeeException {


		Employee employee = null;
		
		try(Connection con = DBUtil.getConnection() ){
			
			PreparedStatement pstm = con.prepareStatement("select * from Employee where Emp_Last_Name=?");
			
			pstm.setString(1, Lname);
			
			ResultSet res = pstm.executeQuery();
			
			if(res.next() == false)
				throw new EmployeeException("No Employee Found with last name "+ Lname);
			
			employee = new Employee();
			
			employee.setEmpId(res.getInt("Emp_ID"));
			employee.setFname(res.getString("Emp_First_Name"));
			employee.setLname(res.getString("Emp_Last_Name"));
			employee.setDOB(res.getDate("Emp_Date_of_Birth"));
			employee.setDOJ(res.getDate("Emp_Date_of_Joining"));
			employee.setDeptId(res.getInt("Emp_Dept_ID"));
			employee.setGrade(res.getString("Emp_Grade"));
			employee.setDesignation(res.getString("Emp_Designation"));
			employee.setBasic(res.getInt("Emp_Basic"));
			employee.setGender(res.getString("Emp_Gender"));
			employee.setMaritalStatus(res.getString("Emp_Marital_Status"));
			employee.setHomeAddress(res.getString("Emp_Home_Address"));
			employee.setCNum(res.getString("Emp_Contact_Num"));
			
			
			
		}
		catch(SQLException e){
			
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
			
		}
		catch(Exception e){
			
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		return employee;
	
		
	}

	@Override
	public Employee getEmployeeByDept(int deptId) throws EmployeeException {
		
Employee employee = null;
		
		try(Connection con = DBUtil.getConnection() ){
			
			PreparedStatement pstm = con.prepareStatement("select * from Employee where Emp_Dept_ID=(select Dept_ID from Department "
					+ "where Dept_Name in (?,?,?,?))");
			
			pstm.setInt(1, deptId);
			
			ResultSet res = pstm.executeQuery();
			
			if(res.next() == false)
				throw new EmployeeException("No Employee Found with id "+ deptId);
			
			employee = new Employee();
			
			
			employee.setEmpId(res.getInt("Emp_ID"));
			employee.setFname(res.getString("Emp_First_Name"));
			employee.setLname(res.getString("Emp_Last_Name"));
			employee.setDOB(res.getDate("Emp_Date_of_Birth"));
			employee.setDOJ(res.getDate("Emp_Date_of_Joining"));
			employee.setDeptId(res.getInt("Emp_Dept_ID"));
			employee.setGrade(res.getString("Emp_Grade"));
			employee.setDesignation(res.getString("Emp_Designation"));
			employee.setBasic(res.getInt("Emp_Basic"));
			employee.setGender(res.getString("Emp_Gender"));
			employee.setMaritalStatus(res.getString("Emp_Marital_Status"));
			employee.setHomeAddress(res.getString("Emp_Home_Address"));
			employee.setCNum(res.getString("Emp_Contact_Num"));
			
			
			
		}
		catch(SQLException e){
			
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
			
		}
		catch(Exception e){
			
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		return employee;

	}
	
	@Override
	public Employee getEmployeeByGrade(String grade) throws EmployeeException 
	{
        Employee employee = null;
		
		try(Connection con = DBUtil.getConnection() )
		{
			
			PreparedStatement pstm = con.prepareStatement("select * from Employee1 where Emp_Grade=(?,?,?,?,?,?,?)");
			
			pstm.setString(1, grade);
			
			ResultSet res = pstm.executeQuery();
				
			if(res.next() == false)
				throw new EmployeeException("No Employee Found with this grade "+ grade);
			
			employee = new Employee();
			
			employee.setEmpId(res.getInt("Emp_ID"));
			employee.setFname(res.getString("Emp_First_Name"));
			employee.setLname(res.getString("Emp_Last_Name"));
			employee.setDOB(res.getDate("Emp_Date_of_Birth"));
			employee.setDOJ(res.getDate("Emp_Date_of_Joining"));
			employee.setDeptId(res.getInt("Emp_Dept_ID"));
			employee.setGrade(res.getString("Emp_Grade"));
			employee.setDesignation(res.getString("Emp_Designation"));
			employee.setBasic(res.getInt("Emp_Basic"));
			employee.setGender(res.getString("Emp_Gender"));
			employee.setMaritalStatus(res.getString("Emp_Marital_Status"));
			employee.setHomeAddress(res.getString("Emp_Home_Address"));
			employee.setCNum(res.getString("Emp_Contact_Num"));
			
		}
       catch(SQLException e){
			
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
			
		}
		catch(Exception e){
			
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		return employee;
			
	 
	}

	@Override
	public Employee getEmployeeByMaritalStatus(String MaritalStatus)
			throws EmployeeException 
	{
		     Employee employee = null;
			
			try(Connection con = DBUtil.getConnection() )
			{
				
				PreparedStatement pstm = con.prepareStatement("select * from Employee1 where Emp_Marital_Status=(?,?,?,?,?)");
				
				pstm.setString(1, MaritalStatus);
				
				ResultSet res = pstm.executeQuery();
					
				if(res.next() == false)
					throw new EmployeeException("No Employee Found with this marital status "+ MaritalStatus);
				
				employee = new Employee();
				
				employee.setEmpId(res.getInt("Emp_ID"));
				employee.setFname(res.getString("Emp_First_Name"));
				employee.setLname(res.getString("Emp_Last_Name"));
				employee.setDOB(res.getDate("Emp_Date_of_Birth"));
				employee.setDOJ(res.getDate("Emp_Date_of_Joining"));
				employee.setDeptId(res.getInt("Emp_Dept_ID"));
				employee.setGrade(res.getString("Emp_Grade"));
				employee.setDesignation(res.getString("Emp_Designation"));
				employee.setBasic(res.getInt("Emp_Basic"));
				employee.setGender(res.getString("Emp_Gender"));
				employee.setMaritalStatus(res.getString("Emp_Marital_Status"));
				employee.setHomeAddress(res.getString("Emp_Home_Address"));
				employee.setCNum(res.getString("Emp_Contact_Num"));
				
			}
	       catch(SQLException e)
			{
				
				e.printStackTrace();
				throw new EmployeeException(e.getMessage());
				
			}
			catch(Exception e)
			{
				
				e.printStackTrace();
				throw new EmployeeException(e.getMessage());
			}
		
		return employee;
	}

	@Override
	public UserBean getUserDetails(String name, String password)
			throws UserException 
	{
		UserBean user=null;
		
		try(Connection con = DBUtil.getConnection() ) 
		{
			PreparedStatement pstm = con.prepareStatement("select * from User_Master where UserName=? and UserPassword=?");
			
			pstm.setString(1, name);
			pstm.setString(2, password);
			
			ResultSet res = pstm.executeQuery();
				
			if(res.next() == false)
				throw new UserException("No user Found with these details ");
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		
		return user;
	}

}
