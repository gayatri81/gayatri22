package com.cg.dao;

import com.cg.bean.Employee;
import com.cg.bean.UserBean;
import com.cg.exception.EmployeeException;
import com.cg.exception.UserException;
import com.sun.corba.se.spi.servicecontext.UEInfoServiceContext;


public interface IEmployeeDAO {
	
	public int addEmployee(Employee employee) throws EmployeeException;
	public Employee getEmployee(int empId) throws EmployeeException;
	public Employee getEmployeeDetailsByFName(String Fname) throws EmployeeException;
	public Employee getEmployeeDetailsByLName(String Lname) throws EmployeeException;
	public Employee getEmployeeByDept(int deptId) throws EmployeeException;
	
	public Employee getEmployeeByGrade(String grade)throws EmployeeException;
	public Employee getEmployeeByMaritalStatus(String MaritalStatus)throws EmployeeException;
	
	public UserBean getUserDetails(String name, String password)throws UserException;

}
